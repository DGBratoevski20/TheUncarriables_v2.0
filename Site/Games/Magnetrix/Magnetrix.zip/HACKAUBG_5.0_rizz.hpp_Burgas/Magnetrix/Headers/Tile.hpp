#pragma once
class Tile
{
public:

	Tile();
	~Tile();

	inline void draw(Vector2 pos, Texture2D* texture);
};