#pragma once
#include <iostream>
#include <raylib.hpp>
#include <vector>
#include <fstream>

#define NUMBER_OF_TILES 10

enum direction {
	NO_ROTATE = 0,
	LEFT = -1,
	RIGHT = 1
};