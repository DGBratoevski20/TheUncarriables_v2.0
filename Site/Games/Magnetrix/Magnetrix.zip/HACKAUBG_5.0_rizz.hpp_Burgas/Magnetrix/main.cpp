#include "pch.hpp"
#include "Gamemanager.hpp"

int main()
{
	GameManager manager;
	manager.start();
}